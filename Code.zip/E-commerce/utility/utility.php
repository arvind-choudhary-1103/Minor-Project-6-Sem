<?php
require('connection.php');
require('function.php');
?>